package com.example.numberlistapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Adapter for the RecyclerView that displays a list of numbers.
 * @param numbers The list of integers to display.
 */
class NumberAdapter(private var numbers: List<Int>) : RecyclerView.Adapter<NumberAdapter.NumberViewHolder>() {

    /**
     * ViewHolder that holds the views for each item in the list.
     */
    class NumberViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // TextView to display the number
        val numberTextView: TextView = itemView.findViewById(R.id.tvNumber)
    }

    /**
     * Called when the RecyclerView needs a new ViewHolder.
     * @return A new NumberViewHolder.
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NumberViewHolder {
        // Inflate the layout for each item from the item_number.xml file
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_number, parent, false)
        return NumberViewHolder(view)
    }

    /**
     * Called by the RecyclerView to display the data at a specific position.
     * @param holder The ViewHolder to be updated.
     * @param position The position of the item.
     */
    override fun onBindViewHolder(holder: NumberViewHolder, position: Int) {
        // Get the number at the current position and set it to the TextView
        holder.numberTextView.text = numbers[position].toString()
    }

    /**
     * Returns the total number of items in the list.
     */
    override fun getItemCount(): Int {
        return numbers.size
    }

    /**
     * Updates the list of numbers and notifies the adapter of the change.
     * @param newNumbers The new list of numbers.
     */
    fun updateData(newNumbers: List<Int>) {
        this.numbers = newNumbers
        // Notify the RecyclerView that the entire dataset has changed to redraw the list
        notifyDataSetChanged()
    }
}
