package com.example.numberlistapp

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    // Declare UI elements
    private lateinit var limitEditText: EditText
    private lateinit var numbersRecyclerView: RecyclerView
    private lateinit var noResultTextView: TextView

    private lateinit var oddRadioButton: RadioButton
    private lateinit var evenRadioButton: RadioButton
    private lateinit var primeRadioButton: RadioButton
    private lateinit var perfectRadioButton: RadioButton
    private lateinit var squareRadioButton: RadioButton
    private lateinit var fibonacciRadioButton: RadioButton

    private lateinit var numberAdapter: NumberAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        limitEditText = findViewById(R.id.etLimit)
        numbersRecyclerView = findViewById(R.id.rvNumbers)
        noResultTextView = findViewById(R.id.tvNoResult)

        oddRadioButton = findViewById(R.id.rbOdd)
        evenRadioButton = findViewById(R.id.rbEven)
        primeRadioButton = findViewById(R.id.rbPrime)
        perfectRadioButton = findViewById(R.id.rbPerfect)
        squareRadioButton = findViewById(R.id.rbSquare)
        fibonacciRadioButton = findViewById(R.id.rbFibonacci)

        // Set up the RecyclerView and listeners
        setupRecyclerView()
        setupListeners()

        // Perform an initial update of the number list
        updateNumberList()
    }

    /**
     * Initializes the RecyclerView, including its adapter and layout manager.
     */
    private fun setupRecyclerView() {
        numberAdapter = NumberAdapter(emptyList())
        numbersRecyclerView.layoutManager = LinearLayoutManager(this)
        numbersRecyclerView.adapter = numberAdapter
    }

    /**
     * Sets up listeners for the EditText and RadioButtons to trigger updates.
     */
    private fun setupListeners() {
        // Add a TextWatcher to the EditText to listen for text changes
        limitEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Update the number list whenever the text changes
                updateNumberList()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Group the RadioButtons and set a click listener for each
        val radioButtons = listOf(oddRadioButton, evenRadioButton, primeRadioButton, perfectRadioButton, squareRadioButton, fibonacciRadioButton)
        radioButtons.forEach { radioButton ->
            radioButton.setOnClickListener {
                // When a RadioButton is clicked, uncheck all others
                radioButtons.forEach { it.isChecked = false }
                // Then, check the clicked one
                radioButton.isChecked = true
                // Finally, update the number list
                updateNumberList()
            }
        }
    }

    /**
     * Updates the list of numbers based on the user's input and selected filter.
     */
    private fun updateNumberList() {
        // Get the limit from the EditText, defaulting to 0 if the input is invalid
        val limit = limitEditText.text.toString().toIntOrNull() ?: 0

        // Determine which list of numbers to generate based on the selected RadioButton
        val numbers = when {
            oddRadioButton.isChecked -> (1..limit).filter { it % 2 != 0 }
            evenRadioButton.isChecked -> (1..limit).filter { it % 2 == 0 }
            primeRadioButton.isChecked -> getPrimeNumbers(limit)
            perfectRadioButton.isChecked -> getPerfectNumbers(limit)
            squareRadioButton.isChecked -> getSquareNumbers(limit)
            fibonacciRadioButton.isChecked -> getFibonacciNumbers(limit)
            else -> emptyList()
        }

        // Show or hide the "no result" message based on whether the list is empty
        if (numbers.isEmpty()) {
            numbersRecyclerView.visibility = View.GONE
            noResultTextView.visibility = View.VISIBLE
        } else {
            numbersRecyclerView.visibility = View.VISIBLE
            noResultTextView.visibility = View.GONE
            // Update the adapter with the new list of numbers
            numberAdapter.updateData(numbers)
        }
    }

    // --- Helper functions for generating number lists ---

    /**
     * Checks if a given number is prime.
     */
    private fun isPrime(n: Int): Boolean {
        if (n <= 1) return false
        for (i in 2..sqrt(n.toDouble()).toInt()) {
            if (n % i == 0) return false
        }
        return true
    }

    /**
     * Returns a list of prime numbers up to a given limit.
     */
    private fun getPrimeNumbers(limit: Int): List<Int> {
        return (2..limit).filter { isPrime(it) }
    }

    /**
     * Returns a list of square numbers up to a given limit.
     */
    private fun getSquareNumbers(limit: Int): List<Int> {
        val squares = mutableListOf<Int>()
        var i = 1
        while (i * i <= limit) {
            squares.add(i * i)
            i++
        }
        return squares
    }

    /**
     * Returns a list of Fibonacci numbers up to a given limit.
     */
    private fun getFibonacciNumbers(limit: Int): List<Int> {
        if (limit < 1) return emptyList()
        val fibonacciSeries = mutableListOf(1)
        var a = 0
        var b = 1
        while (b <= limit) {
            val next = a + b
            a = b
            b = next
            if (b <= limit) {
                fibonacciSeries.add(b)
            }
        }
        return fibonacciSeries
    }

    /**
     * Returns a list of perfect numbers up to a given limit.
     */
    private fun getPerfectNumbers(limit: Int): List<Int> {
        // Perfect numbers are rare, so a predefined list is efficient for this context
        val perfectNumbers = listOf(6, 28, 496, 8128, 33550336)
        return perfectNumbers.filter { it <= limit }
    }
}
