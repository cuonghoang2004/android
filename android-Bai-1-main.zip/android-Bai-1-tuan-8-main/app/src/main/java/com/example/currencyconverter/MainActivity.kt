package com.example.currencyconverter

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * MainActivity là hoạt động chính của ứng dụng Chuyển đổi tiền tệ.
 *
 * The main activity for the Currency Converter application.
 */
class MainActivity : AppCompatActivity() {

    // Khai báo các thành phần giao diện người dùng (UI elements)
    private lateinit var amountFromEditText: EditText // EditText để nhập số tiền cần chuyển đổi
    private lateinit var fromCurrencySpinner: Spinner // Spinner để chọn đơn vị tiền tệ nguồn
    private lateinit var resultTextView: TextView // TextView để hiển thị kết quả
    private lateinit var toCurrencySpinner: Spinner // Spinner để chọn đơn vị tiền tệ đích
    private lateinit var swapButton: ImageView // Nút để hoán đổi tiền tệ

    /**
     * Map chứa tỷ giá hối đoái của các loại tiền tệ so với USD.
     * USD được dùng làm đơn vị tiền tệ cơ sở để tính toán chéo.
     *
     * A map of currency codes to their exchange rates relative to USD.
     * USD is used as the base currency for cross-rate calculations.
     */
    private val exchangeRates = mapOf(
        "USD" to 1.0,      // Đô la Mỹ
        "VND" to 25450.0,  // Đồng Việt Nam
        "EUR" to 0.92,     // Euro
        "JPY" to 157.0,    // Yên Nhật
        "GBP" to 0.79,     // Bảng Anh
        "AUD" to 1.5,      // Đô la Úc
        "CAD" to 1.37,     // Đô la Canada
        "CHF" to 0.9,      // Franc Thụy Sĩ
        "CNY" to 7.25,     // Nhân dân tệ Trung Quốc
        "KRW" to 1380.0    // Won Hàn Quốc
    )

    /**
     * Danh sách các mã tiền tệ có sẵn để chuyển đổi.
     *
     * A list of available currency codes for conversion.
     */
    private val currencies = exchangeRates.keys.toList()

    /**
     * Hàm được gọi khi hoạt động được tạo.
     *
     * Called when the activity is first created.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Khởi tạo các thành phần UI bằng cách tìm ID của chúng trong layout.
        // Initialize UI elements by finding their IDs in the layout.
        amountFromEditText = findViewById(R.id.etAmountFrom)
        fromCurrencySpinner = findViewById(R.id.spinnerFrom)
        resultTextView = findViewById(R.id.tvResult)
        toCurrencySpinner = findViewById(R.id.spinnerTo)
        swapButton = findViewById(R.id.ivSwap)

        // Thiết lập các spinner và các listener.
        // Set up the spinners and listeners.
        setupSpinners()
        setupListeners()
    }

    /**
     * Thiết lập các spinner (menu thả xuống) cho việc chọn tiền tệ.
     *
     * Sets up the spinners for currency selection.
     */
    private fun setupSpinners() {
        // Tạo một ArrayAdapter để hiển thị danh sách các loại tiền tệ.
        // Create an ArrayAdapter to display the list of currencies.
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, currencies)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        // Gán adapter cho cả hai spinner.
        // Assign the adapter to both spinners.
        fromCurrencySpinner.adapter = adapter
        toCurrencySpinner.adapter = adapter

        // Đặt giá trị mặc định cho các spinner.
        // Set default currency selections.
        fromCurrencySpinner.setSelection(currencies.indexOf("USD"))
        toCurrencySpinner.setSelection(currencies.indexOf("VND"))
    }

    /**
     * Thiết lập các listener để xử lý tương tác của người dùng.
     *
     * Sets up the listeners to handle user interactions.
     */
    private fun setupListeners() {
        // Listener cho sự kiện chọn một mục trong spinner.
        // Listener for item selection events on the spinners.
        val selectionListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                // Khi người dùng thay đổi tiền tệ, thực hiện chuyển đổi lại.
                // When the user changes the currency, perform the conversion again.
                convertCurrency()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Không làm gì nếu không có gì được chọn.
                // Do nothing if nothing is selected.
            }
        }

        fromCurrencySpinner.onItemSelectedListener = selectionListener
        toCurrencySpinner.onItemSelectedListener = selectionListener

        // Listener cho sự kiện thay đổi văn bản trong EditText.
        // Listener for text change events in the EditText.
        amountFromEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                // Mỗi khi người dùng nhập số tiền, thực hiện chuyển đổi.
                // Every time the user types an amount, perform the conversion.
                convertCurrency()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Listener cho sự kiện nhấp vào nút hoán đổi.
        // Listener for click events on the swap button.
        swapButton.setOnClickListener {
            swapCurrencies()
        }
    }

    /**
     * Thực hiện việc chuyển đổi tiền tệ dựa trên các lựa chọn hiện tại và số tiền nhập vào.
     *
     * Performs the currency conversion based on the current selections and the input amount.
     */
    private fun convertCurrency() {
        val amountString = amountFromEditText.text.toString()
        // Nếu không có số tiền nào được nhập, xóa kết quả.
        // If no amount is entered, clear the result.
        if (amountString.isEmpty()) {
            resultTextView.text = ""
            return
        }

        val amount = amountString.toDoubleOrNull()
        // Nếu số tiền không hợp lệ, hiển thị thông báo lỗi.
        // If the amount is not a valid number, display an error message.
        if (amount == null) {
            resultTextView.text = "Invalid number"
            return
        }

        // Lấy các loại tiền tệ đã chọn từ spinner.
        // Get the selected currencies from the spinners.
        val fromCurrency = fromCurrencySpinner.selectedItem.toString()
        val toCurrency = toCurrencySpinner.selectedItem.toString()

        // Lấy tỷ giá hối đoái từ map.
        // Get the exchange rates from the map.
        val fromRate = exchangeRates[fromCurrency]!!
        val toRate = exchangeRates[toCurrency]!!

        // Công thức tính toán chuyển đổi tiền tệ:
        // 1. Chuyển đổi số tiền từ `fromCurrency` sang USD: `amountInUSD = amount / fromRate`
        // 2. Chuyển đổi số tiền từ USD sang `toCurrency`: `result = amountInUSD * toRate`
        // Kết hợp lại: `result = (amount / fromRate) * toRate` hoặc `amount * (toRate / fromRate)`
        //
        // Currency conversion formula:
        // 1. Convert the amount from `fromCurrency` to USD: `amountInUSD = amount / fromRate`
        // 2. Convert the amount from USD to `toCurrency`: `result = amountInUSD * toRate`
        // Combined: `result = (amount / fromRate) * toRate` or `amount * (toRate / fromRate)`
        val result = amount * (toRate / fromRate)

        // Định dạng kết quả thành một chuỗi với 2 chữ số thập phân và hiển thị nó.
        // Format the result to a string with two decimal places and display it.
        resultTextView.text = String.format("%.2f", result)
    }

    /**
     * Hoán đổi vị trí của các loại tiền tệ đã chọn và thực hiện chuyển đổi lại.
     *
     * Swaps the selected currencies and triggers a new conversion.
     */
    private fun swapCurrencies() {
        val fromSpinnerPosition = fromCurrencySpinner.selectedItemPosition
        val toSpinnerPosition = toCurrencySpinner.selectedItemPosition

        // Hoán đổi các lựa chọn trong spinner.
        // Swap the selections in the spinners.
        fromCurrencySpinner.setSelection(toSpinnerPosition)
        toCurrencySpinner.setSelection(fromSpinnerPosition)

        // Sau khi hoán đổi, thực hiện chuyển đổi lại với các giá trị mới.
        // After swapping, perform the conversion again with the new values.
        convertCurrency()
    }
}
